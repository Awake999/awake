APW TESTIMONIALS — ALL IN ONE (built 2026-09-07)
1-TEXT/            quotes as txt / csv / json / md. Paste ALL-QUOTES.txt into any AI. PUBLIC-SHORTLIST = ad-ready lines.
2-CARDS-PUBLIC-square/   first-name cards 1080x1080 (feed) — safe for ads
3-CARDS-PUBLIC-story/    first-name cards 1080x1920 (stories/reels)
4-CARDS-INTERNAL-square/ full-name cards (sales team only)
5-CARDS-INTERNAL-story/  full-name cards (sales team only)
6-AI-SETUP/        ChatGPT: paste ChatGPT-custom-instructions-PASTE.txt into Settings > Personalization > Custom instructions.
                   Custom GPT: paste CustomGPT-instructions-PASTE.txt into Instructions; upload everything in CustomGPT-knowledge-UPLOAD/ as Knowledge.
                   Claude: Settings > Capabilities > Skills > upload Claude-skills-UPLOAD.zip
Every quote is verbatim with a proof link. Source of truth: github.com/Awake999/awake (ops/data/testimonials).
