APW testimonial cards. Filename = APW__type__name__profession__date__quote__public|internal__square|story.png
type: result = measurable outcome the client reported; praise = feedback about APW/Alan.
public = first name only (ad-safe, clients only). internal = full name (sales team).
MANIFEST.csv/json map every file to the verbatim quote, date, profession and proof link.
